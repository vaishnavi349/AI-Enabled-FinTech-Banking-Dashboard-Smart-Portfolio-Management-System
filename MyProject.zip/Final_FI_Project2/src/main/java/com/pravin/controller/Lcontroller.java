package com.pravin.controller;

import com.pravin.entity.Fentity;
import com.pravin.repo.Frepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class Lcontroller {

    @Autowired
    private Frepo frepo;

    // Open login page
    @GetMapping("/")
    public String showLoginPage() {
        return "login";
    }

    // Handle login
    @PostMapping("/login")
    public String login(@RequestParam("accountnumber") String accountnumber,
                        @RequestParam("password") String password,
                        HttpSession session) {

        Fentity user = frepo.findByAccountno(accountnumber);

        if (user != null && user.getPassword().equals(password)) {

            // ✅ STORE SESSION (STRING)
            session.setAttribute("accountNo", accountnumber);

            return "redirect:/dashboard";
        }

        return "login";
    }

    // Logout
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}