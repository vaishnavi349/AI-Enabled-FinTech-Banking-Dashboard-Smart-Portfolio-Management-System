package com.pravin.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.pravin.entity.Aentity;
import com.pravin.repo.AdminRepo;
import com.pravin.service.TransactionService;
import com.pravin.model.TransactionModel;

import java.util.List;

@Controller
public class AdminController {

    @Autowired
    private AdminRepo adminRepo;

    @Autowired
    private TransactionService tservice;

    // =========================
    // LOGIN PAGE
    // =========================
    @GetMapping("/admin")
    public String showLoginPage() {
        return "admin-login";
    }

    // =========================
    // LOGIN PROCESS
    // =========================
    @PostMapping("/admin/login")
    public String loginAdmin(@RequestParam String username,
                             @RequestParam String password,
                             HttpSession session,
                             Model model) {

        Aentity admin = adminRepo.findById(username).orElse(null);

        if (admin == null || !admin.getPassword().equals(password)) {
            model.addAttribute("error", "Invalid Admin Credentials");
            return "admin-login";
        }

        session.setAttribute("admin", username);
        return "redirect:/admin/dashboard";
    }

    // =========================
    // DASHBOARD (ONLY ONCE - FIXED)
    // =========================
    @GetMapping("/admin/dashboard")
    public String dashboard(HttpSession session) {

        if (session.getAttribute("admin") == null) {
            return "redirect:/admin";
        }

        return "admin-dashboard";
    }

    // =========================
    // TRANSACTIONS PAGE
    @GetMapping("/admin/transactions")
    public String showTransactions(
            @RequestParam(value = "type", required = false) String type,
            HttpSession session,
            Model model) {

        if (session.getAttribute("admin") == null) {
            return "redirect:/admin";
        }

        List<TransactionModel> list;

        if (type != null && !type.isEmpty()) {
            list = tservice.getTransactionsByType(type);
        } else {
            list = tservice.getAllTransactions();
        }

        model.addAttribute("transactions", list);
        model.addAttribute("selectedType", type);

        return "all-transaction"; // 👈 admin page
    }
    // =========================
    // LOGOUT
    // =========================
    @GetMapping("/admin/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/admin";
    }
}