package com.pravin.controller;

import com.pravin.service.CsvService;

import jakarta.servlet.http.HttpServletResponse;

import com.pravin.repo.StockRepo;
import com.pravin.entity.StockEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.PrintWriter;
import java.util.List;

@RestController
public class StockController {

    @Autowired
    private CsvService csvService;

    @Autowired
    private StockRepo stockRepository;

    @GetMapping("/load-data")
    public String loadData() {
        try {
            csvService.loadCsvToDB(
                "C:/Users/HP/Downloads/PR290426/pr29042026.csv"
            );
            return "Bhav Copy Loaded Successfully!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }

    @GetMapping("/stocks")
    public List<StockEntity> getAll() {
        return stockRepository.findAll();
    }
    @GetMapping("/download-stocks")
    public void downloadStocks(HttpServletResponse response) throws Exception {

        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=stocks.csv");

        List<StockEntity> stocks = stockRepository.findAll();

        PrintWriter writer = response.getWriter();

        writer.println("ID,Company,Open,High,Low,Close,Volume");

        for (StockEntity s : stocks) {
            writer.println(
                s.getId() + "," +
                s.getCompany() + "," +
                s.getOpenPrice() + "," +
                s.getHighPrice() + "," +
                s.getLowPrice() + "," +
                s.getClosePrice() + "," +
                s.getVolume()
            );
        }

        writer.flush();
    }
}