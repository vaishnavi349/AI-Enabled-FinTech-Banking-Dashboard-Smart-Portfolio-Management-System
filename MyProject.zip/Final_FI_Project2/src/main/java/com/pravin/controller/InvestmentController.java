package com.pravin.controller;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

import com.pravin.entity.InvestmentEntity;
import com.pravin.entity.InvestmentHistoryEntity;
import com.pravin.repo.InvestmentHistoryRepo;
import com.pravin.service.InvestmentService;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
public class InvestmentController {

    @Autowired
    private InvestmentService investmentService;

    @Autowired
    private InvestmentHistoryRepo historyRepo;

    // =========================
    // SHOW ADD INVESTMENT PAGE
    // =========================
    @GetMapping("/investment/add")
    public String showAddInvestmentPage() {
        return "addInvestment";
    }

    // =========================
    // SHOW INVESTMENT DASHBOARD
    // =========================
    @GetMapping("/investment")
    public String showInvestmentPage(HttpSession session, Model model) {

        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            return "redirect:/";
        }

        List<InvestmentEntity> list =
                investmentService.getInvestmentsByAccount(accountNo);

        if (list == null) {
            list = new ArrayList<>();
        }

        List<String> dates = new ArrayList<>();
        List<Double> values = new ArrayList<>();
        List<String> suggestions = new ArrayList<>();

        for (InvestmentEntity inv : list) {

            // GRAPH DATA
            dates.add(inv.getDate() != null ?
                    inv.getDate().toString() :
                    LocalDate.now().toString());

            values.add(inv.getCurrentValue());

            // ✅ USE STORED VALUE (NO API CALL)
            double currentValue = inv.getCurrentValue();

            // SUGGESTION LOGIC
            if (currentValue >= inv.getInvestedAmount() * 1.05) {
                suggestions.add("📈 STRONG BUY");
            } else if (currentValue < inv.getInvestedAmount()) {
                suggestions.add("⚠️ SELL / LOSS");
            } else {
                suggestions.add("⚖️ HOLD");
            }
        }

        model.addAttribute("investments", list);
        model.addAttribute("investmentTotal",
                investmentService.totalPortfolioValue(list));
        model.addAttribute("totalProfit",
                investmentService.totalProfit(list));

        model.addAttribute("invDates", dates);
        model.addAttribute("invValues", values);
        model.addAttribute("suggestions", suggestions);

        return "investment";
    }

    // =========================
    // ADD INVESTMENT
    // =========================
    @PostMapping("/investment/add")
    public String addInvestment(@ModelAttribute InvestmentEntity inv,
                               HttpSession session) {

        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            return "redirect:/";
        }

        inv.setAccountNo(accountNo);

        // ✅ Use entered/current value (NO API DEPENDENCY)
        double value = inv.getCurrentValue();

        if (value <= 0) {
            value = inv.getInvestedAmount();
        }

        inv.setCurrentValue(value);
        inv.setDate(LocalDate.now());

        InvestmentEntity saved = investmentService.addInvestment(inv);

        // SAVE HISTORY
        InvestmentHistoryEntity history = new InvestmentHistoryEntity();
        history.setAccountNo(accountNo);
        history.setDate(LocalDate.now());
        history.setValue(value);

        historyRepo.save(history);

        return "redirect:/investment";
    }

    // =========================
    // EXPORT PDF
    // =========================
    @GetMapping("/investment/export")
    public void exportInvestmentPDF(HttpSession session,
                                    HttpServletResponse response) throws Exception {

        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            response.sendRedirect("/");
            return;
        }

        List<InvestmentEntity> list =
                investmentService.getInvestmentsByAccount(accountNo);

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition",
                "attachment; filename=investment_report.pdf");

        PdfWriter writer = new PdfWriter(response.getOutputStream());
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("=== Investment Report ==="));
        document.add(new Paragraph("Account No: " + accountNo));
        document.add(new Paragraph(" "));

        for (InvestmentEntity inv : list) {

            double profit = inv.getCurrentValue() - inv.getInvestedAmount();

            document.add(new Paragraph(
                    "Name: " + inv.getName() +
                    " | Type: " + inv.getType() +
                    " | Invested: ₹" + inv.getInvestedAmount() +
                    " | Current: ₹" + inv.getCurrentValue() +
                    " | Profit: ₹" + profit
            ));
        }

        document.close();
    }
}