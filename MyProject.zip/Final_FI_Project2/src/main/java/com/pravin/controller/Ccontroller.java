package com.pravin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.pravin.entity.StockData;
import com.pravin.service.CService;
import com.pravin.service.MLService;

import java.util.List;

@RestController
@RequestMapping("/stock")
public class Ccontroller {

    @Autowired
    private CService csvService;

    @Autowired
    private MLService mlService;

    // ✅ Test API (check if controller is working)
    @GetMapping("/test")
    public String test() {
        return "Controller is working!";
    }

    // ✅ Train Model API
    @GetMapping("/train")
    public String train() {
        try {
            
        	String path = "C:/Users/HP/Downloads/PR290426/pr29042026.csv";

            System.out.println("Reading CSV from: " + path);

            List<StockData> data = csvService.readCSV(path);

            System.out.println("Data size: " + data.size());

            mlService.train(data);

            return "Model trained successfully! Records: " + data.size();

        } catch (Exception e) {
            e.printStackTrace();
            return "Error during training: " + e.getMessage();
        }
    }

    // ✅ Predict API
    @PostMapping("/predict")
    public String predict(@RequestBody StockData stock) {
        try {
            return mlService.predict(stock);
        } catch (Exception e) {
            e.printStackTrace();
            return "Prediction error: " + e.getMessage();
        }
    }

    
}