package com.pravin.controller;

import com.pravin.entity.Fentity;
import com.pravin.entity.InvestmentEntity;
import com.pravin.entity.InvestmentHistoryEntity;
import com.pravin.model.TransactionModel;
import com.pravin.repo.Frepo;
import com.pravin.repo.TransactionRepo;
import com.pravin.repo.InvestmentHistoryRepo;
import com.pravin.service.InvestmentService;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.format.DateTimeFormatter;
import java.util.*;

@Controller
public class DashboardController {

    @Autowired
    private Frepo frepo;

    @Autowired
    private TransactionRepo trepo;

    @Autowired
    private InvestmentService investmentService;

    @Autowired
    private InvestmentHistoryRepo historyRepo;

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {

        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            return "redirect:/";
        }

        // ================= USER =================
        Fentity user = frepo.findByAccountno(accountNo);

        if (user == null) {
            return "redirect:/";
        }

        // ================= TRANSACTIONS =================
        List<TransactionModel> allTransactions =
                trepo.findByAccountnumberOrderByDateDesc(accountNo);

        List<TransactionModel> lastFive =
                allTransactions.size() > 5 ? allTransactions.subList(0, 5) : allTransactions;

        double income = 0;
        double expense = 0;

        for (TransactionModel t : allTransactions) {
            if ("DEPOSIT".equalsIgnoreCase(t.getType())) {
                income += t.getAmount();
            } else if ("WITHDRAW".equalsIgnoreCase(t.getType())) {
                expense += t.getAmount();
            }
        }

        Map<String, Double> incomeMap = new LinkedHashMap<>();
        Map<String, Double> expenseMap = new LinkedHashMap<>();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM");

        for (TransactionModel t : allTransactions) {

            if (t.getDate() == null) continue;

            String day = t.getDate().format(formatter);

            if ("DEPOSIT".equalsIgnoreCase(t.getType())) {
                incomeMap.put(day,
                        incomeMap.getOrDefault(day, 0.0) + t.getAmount());
            }

            if ("WITHDRAW".equalsIgnoreCase(t.getType())) {
                expenseMap.put(day,
                        expenseMap.getOrDefault(day, 0.0) + t.getAmount());
            }
        }

        // ================= INVESTMENT =================
        List<InvestmentEntity> investments =
                investmentService.getInvestmentsByAccount(accountNo);

        double investmentTotal =
                investmentService.totalPortfolioValue(investments);

        double totalProfit =
                investmentService.totalProfit(investments);

        // ================= INVESTMENT GRAPH (FROM HISTORY) =================
        List<InvestmentHistoryEntity> history =
                historyRepo.findByAccountNo(accountNo);

        List<String> invDates = new ArrayList<>();
        List<Double> invValues = new ArrayList<>();

        if (history != null) {
            for (InvestmentHistoryEntity h : history) {
                if (h.getDate() != null) {
                    invDates.add(h.getDate().toString());
                } else {
                    invDates.add("");
                }

                invValues.add(h.getValue());
            }
        }

        // ================= MODEL =================
        model.addAttribute("user", user);

        model.addAttribute("transactions", lastFive);
        model.addAttribute("income", income);
        model.addAttribute("expense", expense);
        model.addAttribute("incomeMap", incomeMap);
        model.addAttribute("expenseMap", expenseMap);

        model.addAttribute("investments", investments);
        model.addAttribute("investmentTotal", investmentTotal);
        model.addAttribute("totalProfit", totalProfit);

        // 🔥 IMPORTANT FOR GRAPH
        model.addAttribute("invDates", invDates);
        model.addAttribute("invValues", invValues);

        return "dashboard";
    }
        
    
}