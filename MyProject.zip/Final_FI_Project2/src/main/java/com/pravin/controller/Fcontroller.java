package com.pravin.controller;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.ui.Model;
import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;
import com.pravin.entity.Fentity;

import com.pravin.model.Fmodel;

import com.pravin.repo.Frepo;
import com.pravin.service.Fservice;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;


//import ch.qos.logback.core.model.Model;

@Controller
public class Fcontroller {
	@Autowired
	public Fservice fservice;
	@Autowired
	public Frepo frepo1;
	
	
	//@GetMapping("/")
	//public String homePage() {
		//return "home";
	//}
	//Copy This
	@GetMapping("/firstpage")
	public String firstpage()
	{
		return "firstpage";
	}
	//Copy This
	@PostMapping("/savedata")
	public String getData(@RequestParam("fullname") String fullname, @RequestParam("dob")String dob,@RequestParam("fathername")String fathername,
			@RequestParam("image")MultipartFile image,@RequestParam("mobile")String mobile,@RequestParam("email")String email,@RequestParam("idproof")MultipartFile idproof,
			@RequestParam("image2")MultipartFile image2, @RequestParam("pancard")String pancard, @RequestParam("occupation")String occupation,
			@RequestParam("employer")String employer,@RequestParam("accounttype")String accounttype,@RequestParam("deposit")Double deposit,@RequestParam("nominee")String nominee) throws IOException{ 
		
		 fservice.savedata(fullname, dob, fathername, image, mobile, email, idproof, image2, pancard, occupation, 
				employer, accounttype, deposit, nominee);
		
		
		return"redirect:/";
	}
public Frepo frepo;
	
	
	
	public static final  String ACCOUNT_SID = "AC61e0e894f86a18fa74bd7f2eb689c174";
    public static final  String AUTH_TOKEN = "86a3b75a02fb17d6136b5e61b6f05825";
    public static final  String from_number="+17622403399";
    public   String to_number="";
    public Integer saveotp;
   
    static {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
    }

  /*public Fservice(Fcontroller fcontroller) {
		super();
		this.fcontroller = fcontroller;
		
	}*/
	public void savedata(String fullname, String dob,String fathername, MultipartFile image, String mobile, String email,
			MultipartFile idproof, MultipartFile image2, String pancard, String occupation, String employer, String accounttype,
			Double deposit, String nominee) throws IOException {
	
		
		Fentity  en= new Fentity();
		
		en.setFullname(fullname);
		en.setDob(dob);
		en.setFathername(fathername);
		en.setImage(image.getBytes());
		en.setMobile(mobile);
		en.setEmail(email);
		en.setIdproof(idproof.getBytes());
		en.setImage2(image2.getBytes());
		en.setPancard(pancard);
		en.setOccupation(occupation);
		en.setEmployer(employer);
		en.setAccounttype(accounttype);
		en.setDeposit(deposit);
		en.setNominee(nominee);
		
		frepo1.save(en);
		
		
	}
	
public List<Fentity> showAllEnquires() {
		
		return frepo1.findAll();
	}
	
	
	
	 public void generateAccountNumber(Integer sn)
	 {
		 
		 Fentity f = frepo1.findBySn(sn);
		 String status=f.getStatus();
		 System.out.println(status);
		 if(status==null) {
	String prefix = "12345";
	 Random r = new Random();
	 int randomNum = r.nextInt(1000000);
	
	 System.out.println(randomNum);
	 String lastPart = String.format("%06d", randomNum);
	 
	 String account = prefix + lastPart;
	 System.out.println(account);
	 int pass=r.nextInt(1000);
	 String password=String.format("%04d",pass);

	 //Account_Service as=new Account_Service();
	 //as.sendMessage("+917972058856");
	 String mnumber="+919529993652";
	 String to_number= mnumber;
	 System.out.println( to_number);
	 String ot = "Your Account number is:"+account +"\n"+
			 "Your Password is:"+password;
	 //String ps=passStr;
	 System.out.println("+account");
	 Message message = Message.creator(new PhoneNumber(to_number),new PhoneNumber(from_number),ot).create();
	 System.out.println(message.getBody());
	 f.setAccountno(account);
	 f.setPassword(password);
	 f.setStatus("Approved");
	 frepo1.save(f);
	 }else {
		 System.out.println("Account number already exist");
	 }
	 }
	 public void rejectPage(Integer sn) {
	       Fentity   fentity  = frepo1.findBySn(sn);
		 
		 String mnumber = "‪+919529993652";
		 String to_number= mnumber;
		 
		 String msg = "Your account request has been rejected, Kindly request to visit Shree Credit Institution";
		 
		Message message = Message.creator(new PhoneNumber(to_number),new PhoneNumber(from_number), msg).create();
		fentity.setStatus("Rejected");
		frepo1.save(fentity);
		
		
	 }
	 
	
	
}


