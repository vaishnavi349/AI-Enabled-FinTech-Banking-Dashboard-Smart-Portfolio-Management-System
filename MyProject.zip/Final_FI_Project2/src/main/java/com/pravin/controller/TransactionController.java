package com.pravin.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.pravin.service.TransactionService;
import com.pravin.model.TransactionModel;
import com.pravin.entity.Fentity;
import com.pravin.repo.Frepo;
import com.pravin.repo.TransactionRepo;

import java.util.List;

// PDF imports
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

@Controller
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private TransactionService service;

    @Autowired
    private Frepo frepo;

    // =========================
    // OPEN TRANSACTION PAGE
    // =========================
    @GetMapping
    public String showTransactionPage(@RequestParam(required = false) String type,
                                      HttpSession session,
                                      Model model) {

        // ✅ FIXED KEY
        if (session.getAttribute("accountNo") == null) {
            return "redirect:/";
        }

        model.addAttribute("type", type);
        return "transaction";
    }

    // =========================
    // SAVE TRANSACTION
    // =========================
    @PostMapping
    public String doTransaction(@RequestParam double amount,
                               @RequestParam String type,
                               HttpSession session) {

        // ✅ FIXED KEY
        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            return "redirect:/";
        }

        boolean success = service.processTransaction(accountNo, amount, type);

        if (!success) {
            return "redirect:/transaction?error=true";
        }

        return "redirect:/dashboard";
    }

    // =========================
    // HISTORY PAGE
    // =========================
    @Autowired
    private TransactionRepo transactionRepo;
    @GetMapping("/history")
    public String viewHistory(@RequestParam(required = false) String type,
                              HttpSession session,
                              Model model) {

        // ✅ FIXED KEY (same everywhere)
        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            return "redirect:/";
        }

        List<TransactionModel> transactions;

        if (type != null && !type.isEmpty()) {
            // ✅ FIXED (use object, not class)
            transactions = TransactionRepo
                    .findByAccountnumberAndTypeOrderByDateDesc(accountNo, type);
        } else {
            transactions = transactionRepo
                    .findByAccountnumberOrderByDateDesc(accountNo);
        }

        model.addAttribute("transactions", transactions);
        model.addAttribute("selectedType", type);

        return "history";
    }
    // =========================
    // EXPORT PDF
    // =========================
    @GetMapping("/export")
    public void exportPDF(HttpSession session, HttpServletResponse response) throws Exception {

        // ✅ FIXED KEY
        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            response.sendRedirect("/");
            return;
        }

        List<TransactionModel> list = service.getTransactions(accountNo);
        Fentity user = frepo.findByAccountno(accountNo);

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=statement.pdf");

        PdfWriter writer = new PdfWriter(response.getOutputStream());
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("===== FinTech Bank Statement ====="));
        document.add(new Paragraph("Name: " + user.getFullname()));
        document.add(new Paragraph("Account No: " + accountNo));
        document.add(new Paragraph(" "));

        for (TransactionModel t : list) {
            document.add(new Paragraph(
                    t.getDate() + " | " +
                    t.getType() + " | ₹" +
                    t.getAmount()
            ));
        }

        document.add(new Paragraph(" "));
        document.add(new Paragraph("Final Balance: ₹" + user.getBalance()));

        document.close();
    }
}