package com.pravin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    // FIRST LANDING PAGE
    @GetMapping("/home")
    public String homePage() {
        return "home"; // home.html
    }
}