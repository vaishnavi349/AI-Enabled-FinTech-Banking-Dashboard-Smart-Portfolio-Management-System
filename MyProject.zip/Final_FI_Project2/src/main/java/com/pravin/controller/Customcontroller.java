package com.pravin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import com.pravin.entity.Fentity;
import com.pravin.service.Fservice;

@Controller
public class Customcontroller {

    @Autowired
    private Fservice fservice;

    // 🔹 Show all customers
    @GetMapping("/allcustomer")
    public String getAllCustomer(ModelMap modelmap){
        modelmap.addAttribute("enquiry", new Fentity());
        modelmap.addAttribute("all", fservice.showAllEnquires());
        modelmap.addAttribute("title", "Customer Details");
        return "allcustomer";
    }

    // 🔹 Approve
    @PostMapping("/approve/{sn}")
    public String approvePage(@PathVariable("sn") Integer sn) {
        System.out.println(sn);
        fservice.generateAccountNumber(sn);
        return "redirect:/allcustomer";   // FIXED
    }

    // 🔹 Reject
    @PostMapping("/reject/{sn}")
    public String rejectPage(@PathVariable("sn") Integer sn) {
        System.out.println(sn);
        fservice.rejectPage(sn);
        return "redirect:/allcustomer";   // FIXED
    }
}