package com.pravin.controller;

import com.pravin.entity.Fentity;
import com.pravin.repo.Frepo;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/profile")   // ✅ cleaner URL handling
public class EditProfileController {

    @Autowired
    private Frepo frepo;

    // ================= VIEW PROFILE =================
    @GetMapping
    public String profile(HttpSession session, Model model) {

        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            return "redirect:/";
        }

        Fentity user = frepo.findByAccountno(accountNo);

        if (user == null) {   // ✅ safety check
            return "redirect:/";
        }

        model.addAttribute("user", user);

        return "profile";
    }

    // ================= EDIT PAGE =================
    @GetMapping("/edit")
    public String editProfile(HttpSession session, Model model) {

        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            return "redirect:/";
        }

        Fentity user = frepo.findByAccountno(accountNo);

        if (user == null) {
            return "redirect:/";
        }

        model.addAttribute("user", user);

        return "edit-profile";
    }

    // ================= UPDATE PROFILE =================
    @PostMapping("/update")
    public String updateProfile(@ModelAttribute Fentity formUser,
                               HttpSession session) {

        String accountNo = (String) session.getAttribute("accountNo");

        if (accountNo == null) {
            return "redirect:/";
        }

        Fentity user = frepo.findByAccountno(accountNo);

        if (user == null) {
            return "redirect:/";
        }

        // ✅ update ONLY editable fields (VERY IMPORTANT)
        user.setFullname(formUser.getFullname());
        user.setEmail(formUser.getEmail());
        user.setMobile(formUser.getMobile());
        user.setOccupation(formUser.getOccupation());
        user.setEmployer(formUser.getEmployer());
        user.setNominee(formUser.getNominee());

        frepo.save(user);

        return "redirect:/profile";   // ✅ go back to profile
    }
}