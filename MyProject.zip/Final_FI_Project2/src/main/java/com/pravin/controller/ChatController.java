package com.pravin.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.pravin.service.ChatService;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin
public class ChatController {

    @Autowired
    private ChatService chatService;

    @PostMapping
    public Map<String, String> chat(@RequestBody Map<String, String> request) {

        String sessionId = request.getOrDefault("sessionId", "default");
        String message = request.get("message");

        String reply = chatService.chat(sessionId, message);

        return Map.of("reply", reply);
    }
}