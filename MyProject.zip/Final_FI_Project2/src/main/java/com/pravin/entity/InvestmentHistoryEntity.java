package com.pravin.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class InvestmentHistoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountNo;

    @Column(nullable = false)
    private LocalDate date;

    @Column(nullable = false)
    private Double value;

    // getters
    public Long getId() { return id; }

    public String getAccountNo() { return accountNo; }

    public LocalDate getDate() { return date; }

    public Double getValue() { return value; }

    // setters
    public void setId(Long id) { this.id = id; }

    public void setAccountNo(String accountNo) { this.accountNo = accountNo; }

    public void setDate(LocalDate date) { this.date = date; }

    public void setValue(Double value) { this.value = value; }
}