package com.pravin.entity;

import jakarta.persistence.Column;




import org.apache.tomcat.util.codec.binary.Base64;
import org.checkerframework.common.aliasing.qual.Unique;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity

public class Fentity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sn")
	private Integer sn;
	private String fullname ;
	private String dob;
	private String fathername;
	@Lob
	private byte[] image;
	@Column(name = "mobile_no", unique = true, nullable = false, length = 10)
	private String mobile;
	private String email;
	@Lob
	private byte[] idproof;
	@Lob
	private byte[] image2;
	 @Column(name = "pan_card", unique = true, nullable = false, length = 10)
	private String pancard;
	private String occupation;
	private String employer;
	private String accounttype;
	private Double deposit;
	private String nominee;
	private String status;
	private String accountno; 
	private String password;
	private Double balance;
		
	 public String generateBase64image() {
	        return Base64.encodeBase64String(image);  
	    	
	    }
	 public String generateBase64idproof() {
	        return Base64.encodeBase64String(idproof);  
	    	
	    }
	 public String generateBase64image2() {
	        return Base64.encodeBase64String(image2);  
	    	
	    }
	 
}
