package com.pravin.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
public class TransactionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    // 🔗 Link with user account
    @Column(nullable = false)
    private String accountnumber;

    // 💰 Transaction amount
    @Column(nullable = false)
    private double amount;

    // 🔄 Type: DEPOSIT / WITHDRAW
    @Column(nullable = false)
    private String type;

    // 📅 Date & time
    @Column(nullable = false)
    private LocalDateTime date;

    // ✅ Auto-set date when saving
    @PrePersist
    protected void onCreate() {
        this.date = LocalDateTime.now();
    }

    // 🔽 GETTERS & SETTERS

    public int getId() {
        return id;
    }

    public String getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(String accountnumber) {
        this.accountnumber = accountnumber;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public LocalDateTime getDate() {
        return date;
    }

    // ✅ OPTIONAL (useful for debugging)
    @Override
    public String toString() {
        return "TransactionEntity{" +
                "id=" + id +
                ", accountnumber='" + accountnumber + '\'' +
                ", amount=" + amount +
                ", type='" + type + '\'' +
                ", date=" + date +
                '}';
    }
}