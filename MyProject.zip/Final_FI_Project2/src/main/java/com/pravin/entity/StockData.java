package com.pravin.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockData {
    private double currentPrice;
    private double previousClose;
    private double weekHigh;
    private double lowPrice;
    private double movingAvg;
    private double volume;
    private double volatility;
 
}
