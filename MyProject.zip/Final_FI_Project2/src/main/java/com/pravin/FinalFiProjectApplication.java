package com.pravin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalFiProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalFiProjectApplication.class, args);
	}
}
