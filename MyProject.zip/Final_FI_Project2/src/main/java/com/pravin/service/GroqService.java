package com.pravin.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

@Service
public class GroqService {

    @Value("${groq.api.key}")
    private String apiKey;

    private final WebClient webClient;

    public GroqService() {
        this.webClient = WebClient.builder()
                .baseUrl("https://api.groq.com")
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    public String askGroq(String userMessage, String context) {

        // ================= SYSTEM PROMPT =================
        String systemPrompt = """
                You are a strict FinTech AI Assistant.

                RULES:
                - You help users with finance, banking, transactions, SIP, stocks, loans.
                - You MUST NOT invent any financial data.
                - Always prefer CONTEXT if provided.
                - If context is missing, clearly say "I don't have enough data".
                - Keep responses short, clear, and professional.
                - Always use ₹ for currency.
                """;

        // ================= USER PROMPT =================
        String userPrompt =
                "CONTEXT:\n" + (context == null ? "No context available" : context)
                        + "\n\nUSER QUESTION:\n" + userMessage;

        // ================= REQUEST BODY =================
        Map<String, Object> requestBody = Map.of(
                "model", "llama-3.3-70b-versatile",
                "messages", List.of(
                        Map.of("role", "system", "content", systemPrompt),
                        Map.of("role", "user", "content", userPrompt)
                ),
                "temperature", 0.2
        );

        try {
            Map response = webClient.post()
                    .uri("/openai/v1/chat/completions")
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + apiKey)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            if (response == null) {
                return "No response from Groq API.";
            }

            List choices = (List) response.get("choices");
            if (choices == null || choices.isEmpty()) {
                return "No valid response from Groq.";
            }

            Map choice = (Map) choices.get(0);
            Map message = (Map) choice.get("message");

            return message.get("content").toString();

        } catch (Exception e) {
            return "Error calling Groq API: " + e.getMessage();
        }
    }
}