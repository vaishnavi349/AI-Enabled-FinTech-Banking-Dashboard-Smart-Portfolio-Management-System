package com.pravin.service;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.pravin.entity.Fentity;
import com.pravin.repo.Frepo;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@Service
public class Fservice {

    @Autowired
    private Frepo frepo;

    public static final  String ACCOUNT_SID = "AC61e0e894f86a18fa74bd7f2eb689c174";
    public static final  String AUTH_TOKEN = "86a3b75a02fb17d6136b5e61b6f05825";
    public static final  String from_number="+17622403399";

    static {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
    }

    // ✅ Save Data
    public void savedata(String fullname, String dob, String fathername,
                         MultipartFile image, String mobile, String email,
                         MultipartFile idproof, MultipartFile image2,
                         String pancard, String occupation, String employer,
                         String accounttype, Double deposit, String nominee) throws IOException {

        Fentity en = new Fentity();

        en.setFullname(fullname);
        en.setDob(dob);
        en.setFathername(fathername);
        en.setImage(image.getBytes());
        en.setMobile(mobile);
        en.setEmail(email);
        en.setIdproof(idproof.getBytes());
        en.setImage2(image2.getBytes());
        en.setPancard(pancard);
        en.setOccupation(occupation);
        en.setEmployer(employer);
        en.setAccounttype(accounttype);
        en.setDeposit(deposit);
        en.setNominee(nominee);
        en.setBalance(null);
        frepo.save(en);
    }

    // ✅ Show all customers
    public List<Fentity> showAllEnquires() {
        return frepo.findAll();
    }

    // ✅ Approve (Generate account number)
    public void generateAccountNumber(Integer sn) {

        Fentity f = frepo.findBySn(sn);

        if (f != null && f.getStatus() == null) {

            String account = "12345" + new Random().nextInt(1000000);
            String password = String.format("%04d", new Random().nextInt(10000));

            String msg = "Your Account number is: " + account + "\nPassword: " + password;

            Message.creator(
                    new PhoneNumber("+91" + f.getMobile()),   // dynamic number
                    new PhoneNumber(from_number),
                    msg
            ).create();

            f.setAccountno(account);
            f.setPassword(password);
            f.setStatus("Approved");

            frepo.save(f);
        }
    }

    // ✅ Reject
    public void rejectPage(Integer sn) {

        Fentity f = frepo.findBySn(sn);

        if (f != null) {
            Message.creator(
                    new PhoneNumber("+91" + f.getMobile()),
                    new PhoneNumber(from_number),
                    "Your account request has been rejected"
            ).create();

            f.setStatus("Rejected");
            frepo.save(f);
        }
    }
}