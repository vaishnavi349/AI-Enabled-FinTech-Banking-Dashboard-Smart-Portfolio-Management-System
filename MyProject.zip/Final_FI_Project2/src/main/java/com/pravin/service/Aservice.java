package com.pravin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pravin.entity.Aentity;
import com.pravin.repo.AdminRepo;

@Service
public class Aservice {

    @Autowired
    private AdminRepo adminRepo;

    // =========================
    // ADMIN LOGIN
    // =========================
    public Aentity login(String username, String password) {

        Aentity admin = adminRepo.findById(username).orElse(null);

        if (admin != null && admin.getPassword().equals(password)) {
            return admin;
        }

        return null;
    }

    // =========================
    // OPTIONAL: FIND ADMIN
    // =========================
    public Aentity getAdmin(String username) {
        return adminRepo.findById(username).orElse(null);
    }

    // =========================
    // OPTIONAL: CREATE ADMIN
    // =========================
    public Aentity saveAdmin(Aentity admin) {
        return adminRepo.save(admin);
    }
}