package com.pravin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pravin.repo.Lrepo;
import com.pravin.entity.Lentity;

@Service
public class Lservice {

    @Autowired
    private Lrepo repo;

    // ✅ Login logic
    public Lentity login(String acc, String pass) {

        Lentity user = repo.findByAccountnumber(acc);

        if (user != null && user.getPassword().equals(pass)) {
            return user; // ✅ success
        }

        return null; // ❌ fail
    }
}