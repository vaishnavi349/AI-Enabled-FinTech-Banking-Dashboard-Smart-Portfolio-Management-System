package com.pravin.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.pravin.entity.StockData;

@Service
public class CService {

    public List<StockData> readCSV(String filePath) throws Exception {

        List<StockData> list = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;

        // Skip header
        br.readLine();

        while ((line = br.readLine()) != null) {

            // ✅ Handle empty lines
            if (line.trim().isEmpty()) continue;

            String[] data = line.split(",");

            // ✅ Check column length (VERY IMPORTANT)
            if (data.length < 9) {
                System.out.println("Skipping invalid row (less columns): " + line);
                continue;
            }

            try {
                // ✅ Extract numeric columns
                double prevClose = Double.parseDouble(data[2].trim());
                double open = Double.parseDouble(data[3].trim());
                double high = Double.parseDouble(data[4].trim());
                double low = Double.parseDouble(data[5].trim());
                double close = Double.parseDouble(data[6].trim());
                double volume = Double.parseDouble(data[8].trim());

                // ❗ Skip rows with zero volume
                if (volume == 0) continue;

                StockData stock = new StockData(
                        close,          // currentPrice
                        prevClose,      // previousClose
                        high,           // weekHigh
                        low,            // lowPrice
                        close,          // movingAvg
                        volume,         // volume
                        high - low      // volatility
                );

                list.add(stock);

            } catch (Exception e) {
                System.out.println("Skipping row (parse error): " + line);
            }
        }

        // ✅ IMPORTANT: close file
        br.close();

        System.out.println("Total records loaded: " + list.size());

        return list;
    }
}