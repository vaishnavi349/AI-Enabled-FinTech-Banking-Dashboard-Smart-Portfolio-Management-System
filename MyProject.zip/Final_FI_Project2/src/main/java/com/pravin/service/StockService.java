package com.pravin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.pravin.entity.StockEntity;
import com.pravin.repo.StockRepo;

import java.util.List;

@Service
public class StockService {

    @Autowired
    private StockRepo stockRepository;

    public void saveStock(StockEntity stock) {
        stockRepository.save(stock);
    }

    public List<StockEntity> getAllStocks() {
        return stockRepository.findAll();
    }
}