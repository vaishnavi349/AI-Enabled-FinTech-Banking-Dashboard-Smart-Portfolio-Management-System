package com.pravin.service;

import com.pravin.entity.InvestmentEntity;
import com.pravin.repo.InvestmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InvestmentService {

    @Autowired
    private InvestmentRepo repo;

    @Autowired
    private StockApiService stockApiService; // ✅ NEW

    // Add investment
    public InvestmentEntity addInvestment(InvestmentEntity inv) {
        return repo.save(inv);
    }

    // Get investments by account number
    public List<InvestmentEntity> getInvestmentsByAccount(String accountNo) {
        return repo.findByAccountNo(accountNo);
    }

    // Profit of single investment
    public double getProfit(InvestmentEntity inv) {
        return inv.getCurrentValue() - inv.getInvestedAmount();
    }

    // Total portfolio value
    public double totalPortfolioValue(List<InvestmentEntity> list) {
        if (list == null || list.isEmpty()) return 0.0;

        return list.stream()
                .mapToDouble(InvestmentEntity::getCurrentValue)
                .sum();
    }

    // Total profit
    public double totalProfit(List<InvestmentEntity> list) {
        if (list == null || list.isEmpty()) return 0.0;

        return list.stream()
                .mapToDouble(i -> i.getCurrentValue() - i.getInvestedAmount())
                .sum();
    }

    // =========================
    // REAL TIME STOCK VALUE (API)
    // =========================
    public double getLiveStockValue(String stockName) {

        try {
            String symbol = mapStockSymbol(stockName);
            return stockApiService.getStockPrice(symbol);
        } catch (Exception e) {
            System.out.println("API Error: " + e.getMessage());
        }

        return 0.0;
    }

    // Convert name → stock symbol
    private String mapStockSymbol(String name) {

        if (name == null) return "RELIANCE.NS";

        name = name.toUpperCase();

        switch (name) {
            case "TCS":
                return "TCS.NS";

            case "INFOSYS":
            case "INFY":
                return "INFY.NS";

            case "RELIANCE":
                return "RELIANCE.NS";

            case "HDFC":
                return "HDFCBANK.NS";

            default:
                return "RELIANCE.NS";
        }
    }

    // =========================
    // SMART SUGGESTION (IMPROVED)
    // =========================
    public String getSuggestion(InvestmentEntity inv) {

        double invested = inv.getInvestedAmount();
        double current = inv.getCurrentValue();

        if (invested == 0) return "HOLD";

        double profitPercent = ((current - invested) / invested) * 100;

        // 🔥 Improved logic using API trend idea
        if (profitPercent > 8) {
            return "STRONG BUY 📈";
        } else if (profitPercent > 3) {
            return "BUY MORE 👍";
        } else if (profitPercent >= -3) {
            return "HOLD ⚖";
        } else {
            return "SELL ⚠";
        }
    }
}