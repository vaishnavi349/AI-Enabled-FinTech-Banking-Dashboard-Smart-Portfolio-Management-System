
package com.pravin.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.*;

@Service
public class StockApiService {

    private final String API_KEY = "495c19a7d7msh7765cfaf1e74695p1ea8cdjsn47d9ecf4edc7";
    private final String API_HOST = "yh-finance.p.rapidapi.com";

    private Map<String, Double> cache = new HashMap<>();
    private Map<String, Long> cacheTime = new HashMap<>();

    public double getStockPrice(String symbol) {

        long now = System.currentTimeMillis();

        // ✅ Increase cache time to 5 minutes
        if (cache.containsKey(symbol) && (now - cacheTime.get(symbol)) < 300000) {
            System.out.println("Using cached value for " + symbol);
            return cache.get(symbol);
        }

        String url = "https://yh-finance.p.rapidapi.com/stock/v3/get-quote?symbol=" + symbol;

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.set("X-RapidAPI-Key", API_KEY);
        headers.set("X-RapidAPI-Host", API_HOST);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        try {
            ResponseEntity<Map> response =
                    restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);

            if (response.getBody() == null) return getCachedOrDefault(symbol);

            Map body = response.getBody();

            if (!body.containsKey("price")) return getCachedOrDefault(symbol);

            Map price = (Map) body.get("price");

            double stockPrice = Double.parseDouble(price.get("regularMarketPrice").toString());

            // ✅ Save successful result
            cache.put(symbol, stockPrice);
            cacheTime.put(symbol, now);

            return stockPrice;

        } catch (HttpClientErrorException.TooManyRequests e) {

            System.out.println("429 Too Many Requests → using cache");

            return getCachedOrDefault(symbol); // ✅ fallback

        } catch (HttpClientErrorException.Forbidden e) {

            System.out.println("403 Forbidden → check subscription");

            return getCachedOrDefault(symbol); // ✅ fallback

        } catch (Exception e) {

            System.out.println("Stock API Error: " + e.getMessage());

            return getCachedOrDefault(symbol); // ✅ fallback

        }
    }

    // ✅ New helper method
    private double getCachedOrDefault(String symbol) {
        if (cache.containsKey(symbol)) {
            return cache.get(symbol); // return old value
        }
        return 0.0; // safe default
    }
}
