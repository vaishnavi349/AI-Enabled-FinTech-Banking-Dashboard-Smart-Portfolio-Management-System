package com.pravin.service;

import com.pravin.entity.StockEntity;
import com.pravin.repo.StockRepo;
import org.apache.commons.csv.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;

@Service
public class CsvService {

    @Autowired
    private StockRepo stockRepository;

    public void loadCsvToDB(String filePath) throws Exception {

        stockRepository.deleteAll();

        Reader reader = Files.newBufferedReader(Paths.get(filePath));

        CSVParser csvParser = new CSVParser(reader,
                CSVFormat.DEFAULT
                        .withFirstRecordAsHeader()
                        .withIgnoreHeaderCase()
                        .withTrim()
        );

        System.out.println("HEADERS: " + csvParser.getHeaderNames());

        int count = 0;

        for (CSVRecord record : csvParser) {

            try {

                StockEntity stock = new StockEntity();

                // ✔ correct mapping from YOUR CSV
                stock.setCompany(record.get("SECURITY"));

                stock.setOpenPrice(parseDouble(record.get("OPEN_PRICE")));
                stock.setHighPrice(parseDouble(record.get("HIGH_PRICE")));
                stock.setLowPrice(parseDouble(record.get("LOW_PRICE")));
                stock.setClosePrice(parseDouble(record.get("CLOSE_PRICE")));

                stock.setVolume(parseLong(record.get("NET_TRDQTY")));

                // ⚠ date not available → set null OR today's date
                stock.setTradeDate(LocalDate.now());

                stockRepository.save(stock);
                count++;

            } catch (Exception e) {
                System.out.println("❌ Skipped row: " + record);
            }
        }

        csvParser.close();
        reader.close();

        System.out.println("✅ Data Loaded Successfully: " + count);
    }

    private double parseDouble(String value) {
        try {
            return Double.parseDouble(value.replace(",", ""));
        } catch (Exception e) {
            return 0.0;
        }
    }

    private long parseLong(String value) {
        try {
            return Long.parseLong(value.replace(",", ""));
        } catch (Exception e) {
            return 0L;
        }
    }
}