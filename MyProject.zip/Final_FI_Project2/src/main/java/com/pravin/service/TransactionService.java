package com.pravin.service;

import com.pravin.entity.Fentity;
import com.pravin.model.TransactionModel;
import com.pravin.repo.Frepo;
import com.pravin.repo.TransactionRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private Frepo frepo;

    @Autowired
    private TransactionRepo txnRepo;

    // ==============================
    // PROCESS TRANSACTION
    // ==============================
    @Transactional
    public boolean processTransaction(String accountno, Double amount, String type) {

        // 🔐 1. Validate inputs
        if (accountno == null || amount == null || type == null) {
            return false;
        }

        if (amount <= 0) {
            return false;
        }

        // 🔍 2. Fetch user
        Fentity user = frepo.findByAccountno(accountno);

        if (user == null) {
            return false;
        }

        // 💰 3. Get current balance (handle null safely)
        double balance = user.getBalance() != null ? user.getBalance() : 0.0;

        // 💰 4. DEPOSIT
        if (type.equalsIgnoreCase("DEPOSIT")) {
            balance = balance + amount;
        }

        // 💸 5. WITHDRAW
        else if (type.equalsIgnoreCase("WITHDRAW")) {

            if (amount > balance) {
                return false; // insufficient balance
            }

            balance = balance - amount;
        }

        // ❌ INVALID TYPE
        else {
            return false;
        }

        // 💾 6. Update user balance
        user.setBalance(balance);
        frepo.save(user);

        // 🧾 7. Save transaction record
        TransactionModel txn = new TransactionModel();
        txn.setAccountnumber(accountno);
        txn.setAmount(amount);
        txn.setType(type.toUpperCase());
        txnRepo.save(txn);

        return true;
    }

    // ==============================
    // GET TRANSACTION HISTORY
    // ==============================
    public List<TransactionModel> getTransactions(String accountno) {
        return txnRepo.findByAccountnumberOrderByDateDesc(accountno);
    }
    
    public List<TransactionModel> getAllTransactions() {
        return txnRepo.findAll();
    }

    public List<TransactionModel> getTransactionsByType(String type) {
        return txnRepo.findByType(type);
    }
}