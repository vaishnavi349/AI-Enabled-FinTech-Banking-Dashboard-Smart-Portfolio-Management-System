package com.pravin.service;

import org.springframework.stereotype.Service;
import com.pravin.entity.StockData;
import smile.classification.LogisticRegression;

import java.util.List;

@Service
public class MLService {

    private LogisticRegression model;

    // ✅ TRAIN MODEL
    public void train(List<StockData> dataList) {

        if (dataList == null || dataList.size() < 2) {
            System.out.println("Not enough data to train!");
            return;
        }

        int n = dataList.size() - 1;

        double[][] X = new double[n][7];
        int[] y = new int[n];

        int buy = 0, sell = 0, hold = 0;

        for (int i = 0; i < n; i++) {

            StockData today = dataList.get(i);
            StockData tomorrow = dataList.get(i + 1);

            // ✅ FEATURES
            X[i] = new double[]{
                    today.getCurrentPrice(),
                    today.getPreviousClose(),
                    today.getWeekHigh(),
                    today.getLowPrice(),
                    today.getMovingAvg(),
                    today.getVolume(),
                    today.getVolatility()
            };

            // ✅ LABEL CREATION (FIXED THRESHOLD)
            double returnVal = (tomorrow.getCurrentPrice() - today.getCurrentPrice())
                    / today.getCurrentPrice();

            if (returnVal > 0.005) {          // 🔥 0.5% threshold
                y[i] = 0; // BUY
                buy++;
            } else if (returnVal < -0.005) {
                y[i] = 2; // SELL
                sell++;
            } else {
                y[i] = 1; // HOLD
                hold++;
            }
        }

        // ✅ DEBUG OUTPUT
        System.out.println("Training Data Distribution:");
        System.out.println("BUY: " + buy + " | SELL: " + sell + " | HOLD: " + hold);

        // ✅ TRAIN MODEL
        model = LogisticRegression.fit(X, y);

        System.out.println("Model training completed!");
    }

    // ✅ PREDICT METHOD
    public String predict(StockData s) {

        if (model == null) {
            return "Model not trained yet!";
        }

        double[] input = {
                s.getCurrentPrice(),
                s.getPreviousClose(),
                s.getWeekHigh(),
                s.getLowPrice(),
                s.getMovingAvg(),
                s.getVolume(),
                s.getVolatility()
        };

        int result = model.predict(input);

        return reverseLabel(result);
    }

    // ✅ LABEL MAPPING
    private String reverseLabel(int val) {
        switch (val) {
            case 0:
                return "BUY";
            case 1:
                return "HOLD";
            case 2:
                return "SELL";
            default:
                return "HOLD";
        }
    }
}