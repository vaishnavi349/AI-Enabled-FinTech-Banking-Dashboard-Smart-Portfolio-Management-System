package com.pravin.service;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pravin.entity.ChatMessage;
import com.pravin.repo.ChatMessageRepo;

@Service
public class ChatService {

    @Autowired
    private ChatMessageRepo repo;

    @Autowired
    private GroqService groqService;

    public String chat(String sessionId, String userMessage) {

        // SAVE USER MESSAGE
        ChatMessage user = new ChatMessage();
        user.setSessionId(sessionId);
        user.setRole("user");
        user.setContent(userMessage);
        user.setCreatedAt(LocalDateTime.now());
        repo.save(user);

        // BUILD CONTEXT (chat history)
        String context = repo.findBySessionIdOrderByCreatedAtAsc(sessionId)
                .stream()
                .map(m -> m.getRole() + ": " + m.getContent())
                .collect(Collectors.joining("\n"));

        // CALL GROQ
        String reply = groqService.askGroq(userMessage, context);

        // SAVE BOT RESPONSE
        ChatMessage bot = new ChatMessage();
        bot.setSessionId(sessionId);
        bot.setRole("assistant");
        bot.setContent(reply);
        bot.setCreatedAt(LocalDateTime.now());
        repo.save(bot);

        return reply;
    }
    
}