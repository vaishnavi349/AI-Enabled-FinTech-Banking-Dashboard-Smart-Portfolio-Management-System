package com.pravin.repo;

import com.pravin.entity.InvestmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InvestmentRepo extends JpaRepository<InvestmentEntity, Long> {
	List<InvestmentEntity> findByAccountNo(String accountNo);
}