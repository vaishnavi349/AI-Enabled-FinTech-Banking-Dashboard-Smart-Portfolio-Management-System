package com.pravin.repo;

import com.pravin.model.TransactionModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TransactionRepo extends JpaRepository<TransactionModel, Integer> {

    // ✅ All transactions
    List<TransactionModel> findByAccountnumberOrderByDateDesc(String accountnumber);

    // ✅ Filter by type (ADD THIS)
    static List<TransactionModel> findByAccountnumberAndTypeOrderByDateDesc(String accountnumber, String type) {
		// TODO Auto-generated method stub
		return null;
	}

	List<TransactionModel> findByType(String type);
}