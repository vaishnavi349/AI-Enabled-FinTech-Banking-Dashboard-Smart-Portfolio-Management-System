package com.pravin.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pravin.entity.Fentity;

public interface Frepo extends JpaRepository<Fentity, Integer> {
	
public 	Fentity  findBySn(Integer sn);

Fentity findByMobileOrPancard(String mobile, String pancard);

Fentity findByAccountnoAndPassword(String accountno,String password);
 Fentity findByAccountno(String accountno);
 
 
}

