package com.pravin.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pravin.entity.ChatMessage;

public interface ChatMessageRepo extends JpaRepository<ChatMessage, Long> {

    List<ChatMessage> findBySessionIdOrderByCreatedAtAsc(String sessionId);

}