package com.pravin.repo;

import com.pravin.entity.InvestmentHistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InvestmentHistoryRepo extends JpaRepository<InvestmentHistoryEntity, Long> {

    List<InvestmentHistoryEntity> findByAccountNo(String accountNo);
}