package com.pravin.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.pravin.entity.Lentity;

public interface Lrepo extends JpaRepository<Lentity, String> {

    // ✅ Custom method for login
    Lentity findByAccountnumber(String accountNo);
}