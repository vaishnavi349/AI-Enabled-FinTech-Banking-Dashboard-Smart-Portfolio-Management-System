package com.pravin.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pravin.entity.Aentity;

@Repository
public interface AdminRepo extends JpaRepository<Aentity, String> {

    // optional but useful for login
    Aentity findByUsernameAndPassword(String username, String password);
}