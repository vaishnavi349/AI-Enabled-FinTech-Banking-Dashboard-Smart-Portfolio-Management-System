package com.pravin.repo;

import com.pravin.entity.StockEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StockRepo extends JpaRepository<StockEntity, Long> {
}