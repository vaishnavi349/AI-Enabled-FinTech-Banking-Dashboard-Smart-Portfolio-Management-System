package com.pravin.model;
import java.time.LocalDate;

public class InvestmentModel {

	    private Long id;
	    private String type;
	    private Double amount;
	    private Double returnPercent;
	    private LocalDate date;

	    // Default Constructor
	    public InvestmentModel() {
	    }

	    // Parameterized Constructor
	    public InvestmentModel(Long id, String type, Double amount, Double returnPercent, LocalDate date) {
	        this.id = id;
	        this.type = type;
	        this.amount = amount;
	        this.returnPercent = returnPercent;
	        this.date = date;
	    }

	    // Getters and Setters
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public String getType() {
	        return type;
	    }

	    public void setType(String type) {
	        this.type = type;
	    }

	    public Double getAmount() {
	        return amount;
	    }

	    public void setAmount(Double amount) {
	        this.amount = amount;
	    }

	    public Double getReturnPercent() {
	        return returnPercent;
	    }

	    public void setReturnPercent(Double returnPercent) {
	        this.returnPercent = returnPercent;
	    }

	    public LocalDate getDate() {
	        return date;
	    }

	    public void setDate(LocalDate date) {
	        this.date = date;
	    }
	}

