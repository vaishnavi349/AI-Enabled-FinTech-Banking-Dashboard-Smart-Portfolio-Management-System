package com.pravin.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//Copy This
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Fmodel {
	
	private String fullname ;
	private String dob;
	private String fathername;
	private byte[] image;
	private String mobile;
	private String email;
	private byte[] idproof;
	private byte[] image2;
	private String pancard;
	private String occupation;
	private String employer;
	private String accounttype;
	private String deposit;
	private String nominee;
	private String accountno;
	private String password;
	private Double balance;


}
