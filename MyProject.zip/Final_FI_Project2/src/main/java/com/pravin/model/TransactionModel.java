package com.pravin.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
public class TransactionModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private String accountnumber;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false)
    private String type; // DEPOSIT / WITHDRAW

    private LocalDateTime date;

    // ✅ Auto set date
    @PrePersist
    protected void onCreate() {
        this.date = LocalDateTime.now();
    }

    // 🔽 GETTERS & SETTERS

    public int getId() {
        return id;
    }

    public String getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(String accountnumber) {
        this.accountnumber = accountnumber;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public LocalDateTime getDate() {
        return date;
    }
}