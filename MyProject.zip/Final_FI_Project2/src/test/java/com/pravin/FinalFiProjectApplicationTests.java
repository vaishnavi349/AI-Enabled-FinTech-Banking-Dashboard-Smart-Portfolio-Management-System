package com.pravin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalFiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
